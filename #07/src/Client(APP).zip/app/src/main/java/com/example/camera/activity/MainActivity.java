package com.example.camera.activity;


import android.Manifest;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.HandlerThread;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.camera.streaming.StreamingService;
import com.example.camera.streaming.StreamingServiceImpl;
import com.example.camera.R;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback {

    private static final String[] requiredPermissions = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
    };

    private static final int MY_PERMISSIONS_REQUEST_ACCESS_CODE = 1;
    private StreamingService pictureService;
    private boolean checkDistance = false;
    private Socket socket;

    private String ip = "203.255.81.66";
    private int port = 1319;

    private TextView textView;
    private Thread mSendThread;
    private Thread mRecvThread;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermissions();

        pictureService = StreamingServiceImpl.getInstance(this);
        final Switch s1 = (Switch) findViewById(R.id.switch1);
        final Switch s2 = (Switch) findViewById(R.id.switch2);
        textView = (TextView) findViewById(R.id.textView);
        s1.setOnCheckedChangeListener(new switch1Listener());
        s2.setOnCheckedChangeListener(new switch2Listener());

        new ConnectThread(new InetSocketAddress(ip, port)).start();
    }

    class switch1Listener implements CompoundButton.OnCheckedChangeListener {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                MainActivity.this.showToast("Start capture!");
                pictureService.startCapturing();
            } else {
                MainActivity.this.showToast("Stop capture!");
                pictureService.stopCapturing();
                new SendStopThread().start();
            }
        }
    }

    class SendStopThread extends Thread {

        public SendStopThread() {
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        public void run() {
            try {
                if (!socket.isClosed()) {
                    ByteBuffer b = ByteBuffer.allocate(4);
                    b.order(ByteOrder.LITTLE_ENDIAN);
                    b.putInt(0);
                    socket.getOutputStream().write(b.array(), 0, 4);
                    socket.getOutputStream().flush();
                }
            } catch (Exception ex) {
                showToast("종료패킷 전송실패.");
            }
        }
    }

    class switch2Listener implements CompoundButton.OnCheckedChangeListener {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked)
                MainActivity.this.showToast("Distance Detection on!");
            else
                MainActivity.this.showToast("Distance Detection off!");
            checkDistance = isChecked;
        }
    }

    class ConnectThread extends Thread {
        SocketAddress addr;

        public ConnectThread(SocketAddress addr) {
            this.addr = addr;
        }

        public void run() {
            try {
                socket = new Socket();
                socket.connect(addr);
            } catch (Exception ioe) {
                showToast("서버가 닫혀있습니다.");
            }
            mSendThread = new SendThread();
            mRecvThread = new RecvThread();
            mSendThread.start();
            mRecvThread.start();
        }
    }

    class RecvThread extends Thread {
        public RecvThread() {

        }

        @Override
        public void run() {
            while(!isInterrupted()) {
                try {
                    byte[] data = new byte[4];
                    socket.getInputStream().read(data, 0, 4);
                    ByteBuffer b = ByteBuffer.wrap(data);
                    b.order(ByteOrder.LITTLE_ENDIAN);
                    int length = b.getInt();
                    if (length == 0) {
                        socket.getInputStream().read(data, 0, 4);
                        b = ByteBuffer.wrap(data);
                        b.order(ByteOrder.LITTLE_ENDIAN);
                        length = b.getInt();
                        data = new byte[length];
                        socket.getInputStream().read(data, 0, length);
                        final String msg = new String(data, "UTF-8");
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                textView.setText(msg);
                            }
                        });
                    } else {
                        data = new byte[length];
                        socket.getInputStream().read(data, 0, length);
                        String msg = new String(data, "UTF-8");
                        if (!msg.contains("거리") || (checkDistance && msg.contains("거리")))
                            showToast(msg);
                    }
                } catch (Exception e) {
                }
            }
        }
    }


    class SendThread extends Thread {

        public SendThread() {
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        public void run() {
            while(!isInterrupted()) {
                try {
                    if (!StreamingServiceImpl.picturesTaken.isEmpty()) {
                        byte[] pictureData = StreamingServiceImpl.picturesTaken.poll();
                        ByteBuffer b = ByteBuffer.allocate(4);
                        b.order(ByteOrder.LITTLE_ENDIAN);
                        b.putInt(pictureData.length);
                        socket.getOutputStream().write(b.array(), 0, 4);
                        socket.getOutputStream().write(pictureData);
                        socket.getOutputStream().flush();
                    }
                } catch (Exception ex) {
                    showToast("이미지 전송 실패");
                }
            }
        }
    }

    private void showToast(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this.getApplicationContext(), text, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_ACCESS_CODE: {
                if (!(grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    checkPermissions();
                }
            }
        }
    }

    /**
     * checking  permissions at Runtime.
     */
    @TargetApi(Build.VERSION_CODES.M)
    private void checkPermissions() {
        final List<String> neededPermissions = new ArrayList<>();
        for (final String permission : requiredPermissions) {
            if (ContextCompat.checkSelfPermission(getApplicationContext(),
                    permission) != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(permission);
            }
        }
        if (!neededPermissions.isEmpty()) {
            requestPermissions(neededPermissions.toArray(new String[]{}),
                    MY_PERMISSIONS_REQUEST_ACCESS_CODE);
        }
    }

    class CloseThread extends Thread {
        public CloseThread() {
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        public void run() {
            try {
                if (mSendThread != null) {
                    mSendThread.interrupt();
                    mSendThread = null;
                }
                if (mRecvThread != null) {
                    mRecvThread.interrupt();
                    mRecvThread = null;
                }
                if (pictureService != null)
                    pictureService.stopCapturing();
                if (socket == null || !socket.isClosed()) {
                    socket.close();
                    socket = null;
                }
            } catch (Exception ex) {
            } finally {
                MainActivity.this.finishAffinity();
                System.exit(0);
            }
        }
    }

    private void exit() {
        new CloseThread().start();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch(keyCode) {
            case KeyEvent.KEYCODE_BACK:
                new AlertDialog.Builder(MainActivity.this).setTitle("종료").setMessage("프로그램을 종료 하시겠습니까?")
                        .setPositiveButton("예", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                exit();
                            }
                        }).setNegativeButton("아니요", null).show();
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}